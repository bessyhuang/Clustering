import csv
from collections import defaultdict


columns = defaultdict(list) # each value in each column is appended to a list

# row_lst = []
with open('colab_4973_Qc.csv', 'r', encoding='utf-8') as csvfile:
	# rows = csv.reader(csvfile)
	# for r in rows:
	# 	row_lst.append(r)
	reader = csv.DictReader(csvfile) 	# read rows into a dictionary format
	for row in reader: 					# read a row as {column1: value1, column2: value2,...}
		for (k,v) in row.items(): 		# go over each column name and value 
			columns[k].append(v) 		# append the value into the appropriate list based on column name k

# print(columns['Category'])


Category_dict = dict()
index = 0
for row in columns['Category']:
	if row in Category_dict:
		pass
	else:
		Category_dict[row] = index
		index += 1
# print(Category_dict)


with open('output_Qc_4973_for_simpleTransformers.csv', 'a', newline='', encoding='utf-8-sig') as csvfile:
	writer = csv.writer(csvfile)
	writer.writerow(['_id', 'Question', 'Category'])
	for i in range(len(columns['_id'])):
		cat_index = Category_dict[columns['Category'][i]]
		writer.writerow([columns['_id'][i], columns['Question'][i], cat_index])

with open('output_Qc_4973_for_simpleTransformers.txt', 'a', encoding='utf-8')  as f:
	for key in Category_dict:
		f.write(str(Category_dict[key]) + '\t' + key + '\n')
		print(str(Category_dict[key]) + '\t' + key)